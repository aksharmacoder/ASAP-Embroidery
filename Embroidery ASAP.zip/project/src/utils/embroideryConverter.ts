import { EmbroiderySettings } from '../types';

interface StitchData {
  x: number;
  y: number;
  color: string;
}

export function convertToEmbroideryFormat(
  imageData: ImageData,
  settings: EmbroiderySettings
): Blob {
  // Convert image data to stitch data
  const stitches: StitchData[] = generateStitches(imageData, settings);
  
  // Convert stitches to the selected format
  switch (settings.format) {
    case 'DST':
      return convertToDST(stitches);
    case 'EMB':
      return convertToEMB(stitches);
    case 'JEF':
      return convertToJEF(stitches);
    default:
      throw new Error(`Unsupported format: ${settings.format}`);
  }
}

function generateStitches(imageData: ImageData, settings: EmbroiderySettings): StitchData[] {
  const stitches: StitchData[] = [];
  const { width, height } = imageData;
  const stepSize = Math.max(1, Math.floor(10 / settings.stitchDensity));

  for (let y = 0; y < height; y += stepSize) {
    for (let x = 0; x < width; x += stepSize) {
      const idx = (y * width + x) * 4;
      const r = imageData.data[idx];
      const g = imageData.data[idx + 1];
      const b = imageData.data[idx + 2];
      const color = `#${((1 << 24) + (r << 16) + (g << 8) + b).toString(16).slice(1)}`;

      stitches.push({ x, y, color });
    }
  }

  return stitches;
}

function convertToDST(stitches: StitchData[]): Blob {
  // DST format header (512 bytes)
  const header = new Uint8Array(512);
  const content: number[] = [];

  stitches.forEach(stitch => {
    // DST format uses 0.1mm units
    const x = Math.round(stitch.x * 0.1);
    const y = Math.round(stitch.y * 0.1);
    
    // Convert to DST stitch format (3 bytes per stitch)
    content.push(
      (x & 0x7F) | 0x80,
      (y & 0x7F) | 0x80,
      0x03  // Normal stitch
    );
  });

  // Combine header and content
  const data = new Uint8Array([...header, ...content]);
  return new Blob([data], { type: 'application/octet-stream' });
}

function convertToEMB(stitches: StitchData[]): Blob {
  // Simplified EMB format implementation
  const data = new TextEncoder().encode(JSON.stringify(stitches));
  return new Blob([data], { type: 'application/octet-stream' });
}

function convertToJEF(stitches: StitchData[]): Blob {
  // Simplified JEF format implementation
  const data = new TextEncoder().encode(JSON.stringify(stitches));
  return new Blob([data], { type: 'application/octet-stream' });
}