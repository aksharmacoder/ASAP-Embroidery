import { ProcessedImage } from '../types';

// Function to get dominant colors from an image
export async function extractDominantColors(imageUrl: string, maxColors: number): Promise<string[]> {
  return new Promise((resolve) => {
    const img = new Image();
    img.crossOrigin = "Anonymous";
    
    img.onload = () => {
      const canvas = document.createElement('canvas');
      const ctx = canvas.getContext('2d');
      if (!ctx) return resolve([]);

      canvas.width = img.width;
      canvas.height = img.height;
      ctx.drawImage(img, 0, 0);

      const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height).data;
      const colorMap = new Map<string, number>();

      // Sample pixels at regular intervals for better performance
      for (let i = 0; i < imageData.length; i += 16) {
        const r = imageData[i];
        const g = imageData[i + 1];
        const b = imageData[i + 2];
        
        // Convert to hex and count occurrences
        const hex = `#${((1 << 24) + (r << 16) + (g << 8) + b).toString(16).slice(1)}`;
        colorMap.set(hex, (colorMap.get(hex) || 0) + 1);
      }

      // Sort colors by frequency and get top N colors
      const sortedColors = Array.from(colorMap.entries())
        .sort((a, b) => b[1] - a[1])
        .slice(0, maxColors)
        .map(([color]) => color);

      resolve(sortedColors);
    };

    img.src = imageUrl;
  });
}

// Process image and prepare for conversion
export async function processImage(file: File, maxColors: number): Promise<ProcessedImage> {
  const preview = URL.createObjectURL(file);
  
  return new Promise((resolve) => {
    const img = new Image();
    img.onload = async () => {
      const colors = await extractDominantColors(preview, maxColors);
      
      resolve({
        preview,
        colors,
        dimensions: {
          width: img.width,
          height: img.height
        }
      });
    };
    img.src = preview;
  });
}