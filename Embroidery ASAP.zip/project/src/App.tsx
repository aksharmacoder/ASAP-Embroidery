import React, { useState } from 'react';
import { Stethoscope } from 'lucide-react';
import { ImageUpload } from './components/ImageUpload';
import { Settings } from './components/Settings';
import { Preview } from './components/Preview';
import type { EmbroiderySettings, ProcessedImage } from './types';
import { processImage } from './utils/imageProcessing';
import { convertToEmbroideryFormat } from './utils/embroideryConverter';

function App() {
  const [settings, setSettings] = useState<EmbroiderySettings>({
    format: 'DST',
    stitchDensity: 5,
    maxColors: 10,
    size: {
      width: 100,
      height: 100
    }
  });

  const [processedImage, setProcessedImage] = useState<ProcessedImage | null>(null);
  const [converting, setConverting] = useState(false);

  const handleImageUpload = async (file: File) => {
    try {
      const processed = await processImage(file, settings.maxColors);
      setProcessedImage(processed);
    } catch (error) {
      console.error('Error processing image:', error);
      alert('Error processing image. Please try again.');
    }
  };

  const handleConvert = async () => {
    if (!processedImage) return;

    setConverting(true);
    try {
      // Create a canvas to get image data
      const img = new Image();
      img.src = processedImage.preview;
      
      const canvas = document.createElement('canvas');
      const ctx = canvas.getContext('2d');
      if (!ctx) throw new Error('Could not get canvas context');

      canvas.width = settings.size.width;
      canvas.height = settings.size.height;
      ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
      
      const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
      const embroideryFile = convertToEmbroideryFormat(imageData, settings);
      
      // Create download link
      const url = URL.createObjectURL(embroideryFile);
      const a = document.createElement('a');
      a.href = url;
      a.download = `embroidery.${settings.format.toLowerCase()}`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    } catch (error) {
      console.error('Error converting image:', error);
      alert('Error converting image. Please try again.');
    } finally {
      setConverting(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 py-12 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <Stethoscope className="mx-auto h-12 w-12 text-blue-600" />
          <h1 className="mt-4 text-4xl font-bold text-gray-900">Embroidery Image Converter</h1>
          <p className="mt-2 text-lg text-gray-600">
            Transform your images into embroidery-ready files
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <div className="space-y-8">
            <ImageUpload onImageUpload={handleImageUpload} />
            
            {processedImage && (
              <div className="bg-white rounded-lg shadow p-6">
                <h2 className="text-lg font-medium text-gray-900 mb-4">Settings</h2>
                <Settings settings={settings} onSettingsChange={setSettings} />
                
                <button
                  onClick={handleConvert}
                  disabled={converting}
                  className={`mt-6 w-full py-2 px-4 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 ${
                    converting 
                      ? 'bg-gray-400 cursor-not-allowed' 
                      : 'bg-blue-600 hover:bg-blue-700 text-white'
                  }`}
                >
                  {converting ? 'Converting...' : 'Convert to Embroidery File'}
                </button>
              </div>
            )}
          </div>

          <div className="bg-white rounded-lg shadow p-6">
            <h2 className="text-lg font-medium text-gray-900 mb-4">Preview</h2>
            <Preview processedImage={processedImage} />
          </div>
        </div>
      </div>
    </div>
  );
}

export default App;