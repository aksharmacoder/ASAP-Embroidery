import React from 'react';
import type { ProcessedImage } from '../types';

interface PreviewProps {
  processedImage: ProcessedImage | null;
}

export function Preview({ processedImage }: PreviewProps) {
  if (!processedImage) return null;

  return (
    <div className="space-y-4">
      <div className="aspect-square w-full max-w-md mx-auto overflow-hidden rounded-lg border border-gray-200">
        <img
          src={processedImage.preview}
          alt="Preview"
          className="w-full h-full object-contain"
        />
      </div>
      
      <div>
        <h3 className="text-sm font-medium text-gray-700">Detected Colors</h3>
        <div className="mt-2 flex flex-wrap gap-2">
          {processedImage.colors.map((color, index) => (
            <div
              key={index}
              className="w-8 h-8 rounded-full border border-gray-200"
              style={{ backgroundColor: color }}
              title={color}
            />
          ))}
        </div>
      </div>

      <div className="text-sm text-gray-500">
        Dimensions: {processedImage.dimensions.width}px × {processedImage.dimensions.height}px
      </div>
    </div>
  );
}