import React from 'react';
import type { EmbroiderySettings } from '../types';

interface SettingsProps {
  settings: EmbroiderySettings;
  onSettingsChange: (settings: EmbroiderySettings) => void;
}

export function Settings({ settings, onSettingsChange }: SettingsProps) {
  const handleChange = (field: keyof EmbroiderySettings, value: any) => {
    onSettingsChange({ ...settings, [field]: value });
  };

  return (
    <div className="space-y-4">
      <div>
        <label className="block text-sm font-medium text-gray-700">Format</label>
        <select
          value={settings.format}
          onChange={(e) => handleChange('format', e.target.value)}
          className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
        >
          <option value="DST">DST</option>
          <option value="EMB">EMB</option>
          <option value="JEF">JEF</option>
        </select>
      </div>
      
      <div>
        <label className="block text-sm font-medium text-gray-700">Stitch Density</label>
        <input
          type="range"
          min="1"
          max="10"
          value={settings.stitchDensity}
          onChange={(e) => handleChange('stitchDensity', parseInt(e.target.value))}
          className="mt-1 w-full"
        />
        <span className="text-sm text-gray-500">{settings.stitchDensity}</span>
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700">Maximum Colors</label>
        <input
          type="number"
          min="1"
          max="50"
          value={settings.maxColors}
          onChange={(e) => handleChange('maxColors', parseInt(e.target.value))}
          className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
        />
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div>
          <label className="block text-sm font-medium text-gray-700">Width (mm)</label>
          <input
            type="number"
            value={settings.size.width}
            onChange={(e) => handleChange('size', { ...settings.size, width: parseInt(e.target.value) })}
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
          />
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700">Height (mm)</label>
          <input
            type="number"
            value={settings.size.height}
            onChange={(e) => handleChange('size', { ...settings.size, height: parseInt(e.target.value) })}
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
          />
        </div>
      </div>
    </div>
  );
}