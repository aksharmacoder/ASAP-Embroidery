export interface EmbroiderySettings {
  format: 'DST' | 'EMB' | 'JEF';
  stitchDensity: number;
  maxColors: number;
  size: {
    width: number;
    height: number;
  };
}

export interface ProcessedImage {
  preview: string;
  colors: string[];
  dimensions: {
    width: number;
    height: number;
  };
}